import static org.junit.Assert.*;
import org.junit.Test;

public class MessageTest {
    @Test
    public void testMessageLengthValid() {
        Message m = new Message("+27718693002", "Short message");
        assertTrue(m.content.length() <= 250);
    }

    @Test
    public void testMessageLengthTooLong() {
        String longMsg = "a".repeat(251);
        Message m = new Message("+27718693002", longMsg);
        assertTrue(m.content.length() > 250);
    }

    @Test
    public void testRecipientFormatValid() {
        Message m = new Message("+27718693002", "Test");
        assertTrue(m.checkRecipientCell());
    }

    @Test
    public void testRecipientFormatInvalid() {
        Message m = new Message("08575975889", "Test");
        assertFalse(m.checkRecipientCell());
    }

    @Test
    public void testMessageHashFormat() {
        Message m = new Message("+27718693002", "Hi Mike, can you join us for dinner tonight");
        String hash = m.createMessageHash();
        assertTrue(hash.matches("\\d{2}:\\d+:.*"));
    }
}