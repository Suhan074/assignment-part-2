import java.util.Random;
import java.util.ArrayList;
import java.util.List;

public class Message {
    private static int totalMessages = 0;
    private static List<String> sentMessages = new ArrayList<>();

    private String messageID;
    private int messageNumber;
    private String recipient;
    private String content;
    private String messageHash;

    public Message(String recipient, String content) {
        this.messageID = generateMessageID();
        this.messageNumber = totalMessages;
        this.recipient = recipient;
        this.content = content;
        this.messageHash = createMessageHash();
        totalMessages++;
    }

    private String generateMessageID() {
        Random rand = new Random();
        int id = 1000000000 + rand.nextInt(900000000);
        return String.valueOf(id);
    }

    public boolean checkMessageID() {
        return this.messageID.length() <= 10;
    }

    public boolean checkRecipientCell() {
        return recipient.length() <= 10 && recipient.startsWith("+");
    }

    public String createMessageHash() {
        String[] words = content.split(" ");
        String firstWord = words.length > 0 ? words[0] : "";
        String lastWord = words.length > 1 ? words[words.length - 1] : firstWord;
        String prefix = messageID.substring(0, 2);
        return (prefix + ":" + messageNumber + ":" + firstWord + lastWord).toUpperCase();
    }

    public String sendMessage(String choice) {
        switch (choice) {
            case "Send":
                sentMessages.add(this.toString());
                return "Message successfully sent.";
            case "Disregard":
                return "Press 0 to delete message.";
            case "Store":
                // Placeholder for JSON storage
                return "Message successfully stored.";
            default:
                return "Invalid choice.";
        }
    }

    public static String printMessages() {
        return String.join("\n", sentMessages);
    }

    public static int returnTotalMessages() {
        return totalMessages;
    }

    @Override
    public String toString() {
        return "Message ID: " + messageID +
               "\nMessage Hash: " + messageHash +
               "\nRecipient: " + recipient +
               "\nMessage: " + content;
    }
}