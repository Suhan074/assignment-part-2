public class Login {
    private final String correctUsername = "admin";
    private final String correctPassword = "password";

    public boolean loginUser(String username, String password) {
        return username.equals(correctUsername) && password.equals(correctPassword);
    }
}