import java.util.Scanner;
import javax.swing.JOptionPane;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();

        System.out.println("Welcome to QuickChat.");
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (!login.loginUser(username, password)) {
            System.out.println("Login failed. Exiting program.");
            return;
        }

        System.out.println("Login successful!");

        System.out.print("How many messages would you like to send? ");
        int msgLimit = scanner.nextInt();
        scanner.nextLine(); // Consume newline

        int sentCount = 0;

        while (true) {
            System.out.println("\nMenu:");
            System.out.println("1) Send Message");
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.print("Choose an option: ");
            int option = scanner.nextInt();
            scanner.nextLine(); // consume newline

            switch (option) {
                case 1:
                    if (sentCount >= msgLimit) {
                        System.out.println("Message limit reached.");
                        break;
                    }

                    System.out.print("Enter recipient cell number: ");
                    String recipient = scanner.nextLine();

                    System.out.print("Enter message (max 250 characters): ");
                    String content = scanner.nextLine();

                    if (content.length() > 250) {
                        System.out.println("Message exceeds 250 characters by " + (content.length() - 250) + ", please reduce size.");
                        break;
                    }

                    Message msg = new Message(recipient, content);

                    if (!msg.checkRecipientCell()) {
                        System.out.println("Cell phone number is incorrectly formatted or missing international code.");
                        break;
                    }

                    System.out.print("Send, Disregard, or Store message? ");
                    String choice = scanner.nextLine();
                    String result = msg.sendMessage(choice);
                    JOptionPane.showMessageDialog(null, msg.toString(), "Message Info", JOptionPane.INFORMATION_MESSAGE);
                    System.out.println(result);

                    if (choice.equalsIgnoreCase("Send")) {
                        sentCount++;
                    }
                    break;
                case 2:
                    System.out.println("Coming Soon.");
                    break;
                case 3:
                    System.out.println("Exiting program.");
                    System.out.println("Total messages sent: " + Message.returnTotalMessages());
                    return;
                default:
                    System.out.println("Invalid option.");
            }
        }
    }
}